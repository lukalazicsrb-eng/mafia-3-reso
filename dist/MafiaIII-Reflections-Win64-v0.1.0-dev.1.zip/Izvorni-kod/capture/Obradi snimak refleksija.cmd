@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Export-ReflectionCapture.ps1" %*
set "status=%ERRORLEVEL%"
echo.
pause
exit /b %status%
